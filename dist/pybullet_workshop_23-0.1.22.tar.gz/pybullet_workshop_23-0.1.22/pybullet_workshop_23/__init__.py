from gym.envs.registration import register

register(
    id='pybullet_workshop_23',
    entry_point='pybullet_workshop_23.envs:PybulletEnv',
)